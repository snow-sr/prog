function sendMessage(){
    var email = document.getElementById("email").value;
    var name = document.getElementById("name").value;

    alert(`Obrigado por mandar sua mensagem ${name}! Entraremos em contato com você pelo email informado: ${email}`)
}